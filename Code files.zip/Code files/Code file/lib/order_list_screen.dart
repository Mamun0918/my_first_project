import 'package:flutter/material.dart';

class OrderListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Order List'),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.shopping_bag),
            title: Text('Order #1234'),
            subtitle: Text('Customer: John Doe\nTotal: \$100'),
            trailing: Icon(Icons.more_vert),
          ),
          ListTile(
            leading: Icon(Icons.shopping_bag),
            title: Text('Order #1235'),
            subtitle: Text('Customer: Jane Smith\nTotal: \$150'),
            trailing: Icon(Icons.more_vert),
          ),
          // Add more orders here
        ],
      ),
    );
  }
}
