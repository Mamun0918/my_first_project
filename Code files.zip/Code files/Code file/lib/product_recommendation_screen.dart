import 'package:flutter/material.dart';

class ProductRecommendationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Recommendations'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(10, (index) {
          return Card(
            child: Column(
              children: <Widget>[
                Image.asset('assets/product_placeholder.png'),
                Text('Product ${index + 1}'),
                Text('\$${(index + 1) * 10}'),
              ],
            ),
          );
        }),
      ),
    );
  }
}
