import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:flutter/services.dart' show rootBundle;

class ChatbotScreen extends StatefulWidget {
  @override
  _ChatbotScreenState createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Map<String, dynamic>> _messages = [];
  late String projectId;
  late String sessionId;
  late String languageCode;
  late String token;

  @override
  void initState() {
    super.initState();
    _loadCredentials();
  }

  Future<void> _loadCredentials() async {
    String data = await rootBundle.loadString('assets/dialogflow_key.json');
    final credentials = json.decode(data);

    setState(() {
      projectId = credentials['project_id'];
      sessionId = credentials['session_id'];
      languageCode = credentials['language_code'];
      token = credentials['token'];
    });
  }

  void _handleSubmitted(String text) {
    _controller.clear();
    setState(() {
      _messages.insert(0, {"data": 1, "message": text});
    });
    _response(text);
  }

  Future<void> _response(String query) async {
    final url = Uri.https(
      'dialogflow.googleapis.com',
      '/v2/projects/$projectId/agent/sessions/$sessionId:detectIntent',
    );

    final response = await http.post(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: json.encode({
        "queryInput": {
          "text": {
            "text": query,
            "languageCode": languageCode,
          },
        },
      }),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final String fulfillmentText =
          data['queryResult']['fulfillmentText'] ?? "I didn't understand that.";

      setState(() {
        _messages.insert(0, {"data": 0, "message": fulfillmentText});
      });
    } else {
      setState(() {
        _messages.insert(0, {
          "data": 0,
          "message": "Error: Unable to connect to Dialogflow API",
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chatbot"),
      ),
      body: Column(
        children: <Widget>[
          Flexible(
            child: ListView.builder(
              reverse: true,
              itemBuilder: (context, index) => _buildMessageItem(_messages[index]),
              itemCount: _messages.length,
            ),
          ),
          Divider(height: 1.0),
          Container(
            padding: EdgeInsets.only(bottom: 8.0),
            child: _buildTextComposer(),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageItem(Map<String, dynamic> msg) {
    return Padding(
      padding: EdgeInsets.all(10.0),
      child: Align(
        alignment: msg["data"] == 0 ? Alignment.centerLeft : Alignment.centerRight,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            color: msg["data"] == 0 ? Colors.grey[300] : Colors.blueAccent,
          ),
          padding: EdgeInsets.all(10.0),
          child: Text(
            msg["message"],
            style: TextStyle(fontSize: 15, color: Colors.black),
          ),
        ),
      ),
    );
  }

  Widget _buildTextComposer() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Row(
        children: <Widget>[
          Flexible(
            child: TextField(
              controller: _controller,
              onSubmitted: _handleSubmitted,
              decoration: InputDecoration.collapsed(hintText: "Send a message"),
            ),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.0),
            child: IconButton(
              icon: Icon(Icons.send),
              onPressed: () => _handleSubmitted(_controller.text),
            ),
          ),
        ],
      ),
    );
  }
}
