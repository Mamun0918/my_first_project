import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'signup_screen.dart';

import 'order_list_screen.dart';
import 'order_tracking_screen.dart';
import 'product_recommendation_screen.dart';
import 'chatbot_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Online Ordering',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
        '/signup': (context) => SignupScreen(),

        '/orderlist': (context) => OrderListScreen(),
        '/ordertracking': (context) => OrderTrackingScreen(),
        '/recommendations': (context) => ProductRecommendationScreen(),
        '/chatbot': (context) => ChatbotScreen(),
      },
    );
  }
}
