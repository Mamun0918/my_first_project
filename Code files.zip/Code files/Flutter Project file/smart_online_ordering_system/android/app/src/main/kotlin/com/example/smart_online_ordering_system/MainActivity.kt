package com.example.smart_online_ordering_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
