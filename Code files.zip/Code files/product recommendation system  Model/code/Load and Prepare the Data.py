import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

# Load the dataset
ratings = pd.read_csv('https://raw.githubusercontent.com/ml-bootcamp/recommender-system-tutorial/master/data/ratings.csv')
movies = pd.read_csv('https://raw.githubusercontent.com/ml-bootcamp/recommender-system-tutorial/master/data/movies.csv')

# Merge datasets
data = pd.merge(ratings, movies, on='movieId')

# Prepare data
user_ids = data['userId'].unique().tolist()
user2user_encoded = {x: i for i, x in enumerate(user_ids)}
user_encoded2user = {i: x for i, x in enumerate(user_ids)}
movie_ids = data['movieId'].unique().tolist()
movie2movie_encoded = {x: i for i, x in enumerate(movie_ids)}
movie_encoded2movie = {i: x for i, x in enumerate(movie_ids)}
data['user'] = data['userId'].map(user2user_encoded)
data['movie'] = data['movieId'].map(movie2movie_encoded)

num_users = len(user2user_encoded)
num_movies = len(movie_encoded2movie)
data['rating'] = data['rating'].values.astype(np.float32)

min_rating = min(data['rating'])
max_rating = max(data['rating'])

print(f'Number of users: {num_users}, Number of movies: {num_movies}, Min rating: {min_rating}, Max rating: {max_rating}')

# Split the data
x = data[['user', 'movie']].values
y = data['rating'].values
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
