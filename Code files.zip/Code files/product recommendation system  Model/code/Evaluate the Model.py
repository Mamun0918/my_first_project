# Evaluate the model
loss = model.evaluate([x_test[:, 0], x_test[:, 1]], y_test, verbose=1)
print(f'Test Loss: {loss}')
