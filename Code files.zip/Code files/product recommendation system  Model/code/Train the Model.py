# Train the model
history = model.fit(
    [x_train[:, 0], x_train[:, 1]],
    y_train,
    batch_size=64,
    epochs=5,
    verbose=1,
    validation_data=([x_test[:, 0], x_test[:, 1]], y_test)
)
