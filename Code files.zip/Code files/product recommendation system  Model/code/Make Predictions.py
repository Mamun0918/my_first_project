# Make a prediction
user_id = 1  # Example user ID
movie_id = 1  # Example movie ID

user = np.array([user2user_encoded[user_id]])
movie = np.array([movie2movie_encoded[movie_id]])

predicted_rating = model.predict([user, movie])
print(f'Predicted rating for user {user_id} and movie {movie_id} is {predicted_rating}')
