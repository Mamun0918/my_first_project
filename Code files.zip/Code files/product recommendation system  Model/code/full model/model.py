import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.layers import Input, Embedding, Flatten, Dense, Concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam

# Load the dataset
ratings = pd.read_csv('https://raw.githubusercontent.com/ml-bootcamp/recommender-system-tutorial/master/data/ratings.csv')
movies = pd.read_csv('https://raw.githubusercontent.com/ml-bootcamp/recommender-system-tutorial/master/data/movies.csv')

# Merge datasets
data = pd.merge(ratings, movies, on='movieId')

# Prepare data
user_ids = data['userId'].unique().tolist()
user2user_encoded = {x: i for i, x in enumerate(user_ids)}
user_encoded2user = {i: x for i, x in enumerate(user_ids)}
movie_ids = data['movieId'].unique().tolist()
movie2movie_encoded = {x: i for i, x in enumerate(movie_ids)}
movie_encoded2movie = {i: x for i, x in enumerate(movie_ids)}
data['user'] = data['userId'].map(user2user_encoded)
data['movie'] = data['movieId'].map(movie2movie_encoded)

num_users = len(user2user_encoded)
num_movies = len(movie_encoded2movie)
data['rating'] = data['rating'].values.astype(np.float32)

min_rating = min(data['rating'])
max_rating = max(data['rating'])

print(f'Number of users: {num_users}, Number of movies: {num_movies}, Min rating: {min_rating}, Max rating: {max_rating}')

# Split the data
x = data[['user', 'movie']].values
y = data['rating'].values
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# Define the model
def create_model(num_users, num_movies, embedding_size=50):
    user_input = Input(shape=(1,), name='user')
    user_embedding = Embedding(num_users, embedding_size, name='user_embedding')(user_input)
    user_vector = Flatten(name='user_vector')(user_embedding)

    movie_input = Input(shape=(1,), name='movie')
    movie_embedding = Embedding(num_movies, embedding_size, name='movie_embedding')(movie_input)
    movie_vector = Flatten(name='movie_vector')(movie_embedding)

    concatenated = Concatenate()([user_vector, movie_vector])
    dense_1 = Dense(128, activation='relu')(concatenated)
    dense_2 = Dense(64, activation='relu')(dense_1)
    output = Dense(1, activation='linear')(dense_2)

    model = Model(inputs=[user_input, movie_input], outputs=output)
    model.compile(optimizer=Adam(learning_rate=0.001), loss='mean_squared_error')

    return model

model = create_model(num_users, num_movies)
model.summary()

# Train the model
history = model.fit(
    [x_train[:, 0], x_train[:, 1]],
    y_train,
    batch_size=64,
    epochs=5,
    verbose=1,
    validation_data=([x_test[:, 0], x_test[:, 1]], y_test)
)

# Evaluate the model
loss = model.evaluate([x_test[:, 0], x_test[:, 1]], y_test, verbose=1)
print(f'Test Loss: {loss}')

# Make a prediction
user_id = 1  # Example user ID
movie_id = 1  # Example movie ID

user = np.array([user2user_encoded[user_id]])
movie = np.array([movie2movie_encoded[movie_id]])

predicted_rating = model.predict([user, movie])
print(f'Predicted rating for user {user_id} and movie {movie_id} is {predicted_rating}')
