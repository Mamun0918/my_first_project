import tensorflow as tf
from tensorflow.keras.layers import Input, Embedding, Flatten, Dense, Concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam

# Define the model
def create_model(num_users, num_movies, embedding_size=50):
    user_input = Input(shape=(1,), name='user')
    user_embedding = Embedding(num_users, embedding_size, name='user_embedding')(user_input)
    user_vector = Flatten(name='user_vector')(user_embedding)

    movie_input = Input(shape=(1,), name='movie')
    movie_embedding = Embedding(num_movies, embedding_size, name='movie_embedding')(movie_input)
    movie_vector = Flatten(name='movie_vector')(movie_embedding)

    concatenated = Concatenate()([user_vector, movie_vector])
    dense_1 = Dense(128, activation='relu')(concatenated)
    dense_2 = Dense(64, activation='relu')(dense_1)
    output = Dense(1, activation='linear')(dense_2)

    model = Model(inputs=[user_input, movie_input], outputs=output)
    model.compile(optimizer=Adam(learning_rate=0.001), loss='mean_squared_error')

    return model

model = create_model(num_users, num_movies)
model.summary()
