// scripts/order_list.js
document.addEventListener("DOMContentLoaded", function () {
  console.log("Order List loaded.");

  // Example order data
  var orders = [
    { id: 1234, customer: "John Doe", total: "$100" },
    { id: 1235, customer: "Jane Smith", total: "$150" }
  ];

  var orderList = document.getElementById("orders");
  orders.forEach(function (order) {
    var li = document.createElement("li");
    li.textContent = `Order #${order.id} - ${order.customer} - ${order.total}`;
    orderList.appendChild(li);
  });
});
