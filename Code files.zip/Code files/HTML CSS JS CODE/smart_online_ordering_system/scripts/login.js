// scripts/login.js
function login() {
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;

  // Implement login functionality here
  console.log("Logging in with", email, password);

  // Mock login functionality
  if (email === "user@example.com" && password === "password") {
    alert("Login successful!");
    window.location.href = "dashboard.html";
  } else {
    alert("Invalid email or password.");
  }
}

function navigateToSignup() {
  window.location.href = "signup.html";
}

document.addEventListener("DOMContentLoaded", function () {
  console.log("Login screen loaded.");
});
