// scripts/order_tracking.js
document.addEventListener("DOMContentLoaded", function () {
  console.log("Order Tracking loaded.");

  // Implement order tracking functionality here
  // Example order tracking data
  var trackingInfo = {
    orderId: 1234,
    status: "Shipped",
    expectedDelivery: "3-5 business days"
  };

  document.getElementById("order-tracking").innerHTML = `
    <p>Order #${trackingInfo.orderId}</p>
    <p>Status: ${trackingInfo.status}</p>
    <p>Expected Delivery: ${trackingInfo.expectedDelivery}</p>
  `;
});
