// scripts/chatbot.js
function sendMessage() {
  var messageInput = document.getElementById("message-input");
  var message = messageInput.value;

  if (message.trim() !== "") {
    displayMessage("User", message);
    messageInput.value = "";

    // Call Dialogflow API or a mock response
    displayMessage("Bot", "This is a response from the bot.");
  }
}

function displayMessage(sender, message) {
  var chatMessages = document.getElementById("chat-messages");
  var messageDiv = document.createElement("div");
  messageDiv.className = sender.toLowerCase() + "-message";
  messageDiv.textContent = sender + ": " + message;
  chatMessages.appendChild(messageDiv);
}

document.addEventListener("DOMContentLoaded", function () {
  console.log("Chatbot loaded.");
});
