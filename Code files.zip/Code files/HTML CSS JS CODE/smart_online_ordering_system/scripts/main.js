// scripts/main.js
document.addEventListener("DOMContentLoaded", function () {
  console.log("Smart Online Ordering System initialized.");
});
