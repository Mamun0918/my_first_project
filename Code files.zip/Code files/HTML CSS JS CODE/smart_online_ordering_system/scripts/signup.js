// scripts/signup.js
function signup() {
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;

  // Implement signup functionality here
  console.log("Signing up with", email, password);

  // Mock signup functionality
  if (email !== "" && password !== "") {
    alert("Signup successful!");
    window.location.href = "login.html";
  } else {
    alert("Please enter a valid email and password.");
  }
}

document.addEventListener("DOMContentLoaded", function () {
  console.log("Signup screen loaded.");
});
