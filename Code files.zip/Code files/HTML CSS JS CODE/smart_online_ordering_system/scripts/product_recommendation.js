// scripts/product_recommendation.js
document.addEventListener("DOMContentLoaded", function () {
  console.log("Product Recommendations loaded.");

  // Example product data
  var products = [
    { name: "Product 1", price: "$10" },
    { name: "Product 2", price: "$20" }
  ];

  var productList = document.getElementById("products");
  products.forEach(function (product) {
    var div = document.createElement("div");
    div.textContent = `${product.name} - ${product.price}`;
    productList.appendChild(div);
  });
});
